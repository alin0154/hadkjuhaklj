<?php include_once("./include/reception/header.php"); ?>
<fieldset class="layui-elem-field">
  <legend>ip查询精准位置</legend>

 <iframe src=https://chaipip.com/ width="100%" height="600px" frameborder="0"></iframe>

</fieldset>
<?php include_once("./include/reception/footer.php"); ?>

