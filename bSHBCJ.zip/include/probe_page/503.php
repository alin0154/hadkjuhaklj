<?php
/*
503页面
*/
echo '
<html>
<head>
<title>503 Service Unavailable</title>
</head>
<body>
<h1>503 Service Unavailable</h1>
<p>No server is available to handle this  request</p>
</body>
</html>';
?>

